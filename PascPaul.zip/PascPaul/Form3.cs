﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PascPaul
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }
        int nr = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox2.Image = Image.FromFile("x.png");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox2.Image = Image.FromFile("bifa.png");
            nr++;
            if (nr == 9)
            {
                this.Hide();
                Form9 f = new Form9();
                f.Show();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox2.Image = Image.FromFile("x.png");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = Image.FromFile("bifa.png");
            nr++;
            if (nr == 9)
            {
                this.Hide();
                Form9 f = new Form9();
                f.Show();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = Image.FromFile("x.png");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = Image.FromFile("x.png");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            pictureBox4.Image = Image.FromFile("x.png");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            pictureBox4.Image = Image.FromFile("x.png");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            pictureBox4.Image = Image.FromFile("bifa.png");
            nr++;
            if (nr == 9)
            {
                this.Hide();
                Form9 f = new Form9();
                f.Show();
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            pictureBox5.Image = Image.FromFile("bifa.png");
            nr++;
            if (nr == 9)
            {
                this.Hide();
                Form9 f = new Form9();
                f.Show();
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            pictureBox5.Image = Image.FromFile("x.png");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            pictureBox5.Image = Image.FromFile("x.png");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            pictureBox6.Image = Image.FromFile("x.png");
        }

        private void button14_Click(object sender, EventArgs e)
        {
            pictureBox6.Image = Image.FromFile("bifa.png");
            nr++;
            if (nr == 9)
            {
                this.Hide();
                Form9 f = new Form9();
                f.Show();
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            pictureBox6.Image = Image.FromFile("x.png");
        }

        private void button16_Click(object sender, EventArgs e)
        {
            pictureBox7.Image = Image.FromFile("bifa.png");
            nr++;
            if (nr == 9)
            {
                this.Hide();
                Form9 f = new Form9();
                f.Show();
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            pictureBox7.Image = Image.FromFile("x.png");
        }

        private void button18_Click(object sender, EventArgs e)
        {
            pictureBox7.Image = Image.FromFile("x.png");
        }

        private void button19_Click(object sender, EventArgs e)
        {
            pictureBox8.Image = Image.FromFile("x.png");
        }

        private void button20_Click(object sender, EventArgs e)
        {
            pictureBox8.Image = Image.FromFile("bifa.png");
            nr++;
            if (nr == 9)
            {
                this.Hide();
                Form9 f = new Form9();
                f.Show();
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            pictureBox8.Image = Image.FromFile("x.png");
        }

        private void button22_Click(object sender, EventArgs e)
        {
            pictureBox9.Image = Image.FromFile("x.png");
        }

        private void button23_Click(object sender, EventArgs e)
        {
            pictureBox9.Image = Image.FromFile("x.png");
        }

        private void button24_Click(object sender, EventArgs e)
        {
            pictureBox9.Image = Image.FromFile("bifa.png");
            nr++;
            if (nr == 9)
            {
                this.Hide();
                Form9 f = new Form9();
                f.Show();
            }
        }

        private void button25_Click(object sender, EventArgs e)
        {
            pictureBox10.Image = Image.FromFile("bifa.png");
            nr++;
            if (nr == 9)
            {
                this.Hide();
                Form9 f = new Form9();
                f.Show();
            }
        }

        private void button26_Click(object sender, EventArgs e)
        {
            pictureBox10.Image = Image.FromFile("x.png");
        }

        private void button27_Click(object sender, EventArgs e)
        {
            pictureBox10.Image = Image.FromFile("x.png");
        }

        private void button28_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f = new Form1();
            f.Show();
        }
    }
}
