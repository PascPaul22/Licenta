﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PascPaul
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            label9.Visible = false;
            DoubleBuffered = true;
        }
        int x = 0;
        int y = 0;
        int nr = 0;
        bool miscare = false;

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (miscare)
            {
                //noua pozitie a imaginii
                pictureBox1.Top += e.Y - y;
                pictureBox1.Left += e.X - x;
            }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            //pozitia initiala a cursorului
            x = e.X;
            y = e.Y;
            miscare = true;
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            miscare = false;
            Collision();
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            label1.Visible = false;
        }

        private void pictureBox1_MouseEnter(object sender, EventArgs e)
        {
            label1.Visible = true;
        }

        private void pictureBox2_MouseDown(object sender, MouseEventArgs e)
        {
            //pozitia initiala a cursorului
            x = e.X;
            y = e.Y;
            miscare = true;
        }

        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            if (miscare)
            {
                //noua pozitie a imaginii
                pictureBox2.Top += e.Y - y;
                pictureBox2.Left += e.X - x;
            }
        }

        private void pictureBox2_MouseUp(object sender, MouseEventArgs e)
        {
            miscare = false;
            Collision();
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            label2.Visible = false;
        }

        private void pictureBox2_MouseEnter(object sender, EventArgs e)
        {
            label2.Visible = true;
        }

        private void pictureBox3_MouseDown(object sender, MouseEventArgs e)
        {
            //pozitia initiala a cursorului
            x = e.X;
            y = e.Y;
            miscare = true;
        }

        private void pictureBox3_MouseEnter(object sender, EventArgs e)
        {
            label3.Visible = true;
        }

        private void pictureBox3_MouseLeave(object sender, EventArgs e)
        {
            label3.Visible = false;
        }

        private void pictureBox3_MouseMove(object sender, MouseEventArgs e)
        {
            if (miscare)
            {
                //noua pozitie a imaginii
                pictureBox3.Top += e.Y - y;
                pictureBox3.Left += e.X - x;
            }

        }

        private void pictureBox3_MouseUp(object sender, MouseEventArgs e)
        {
            miscare = false;
            Collision();
        }

        private void pictureBox4_MouseDown(object sender, MouseEventArgs e)
        {
            //pozitia initiala a cursorului
            x = e.X;
            y = e.Y;
            miscare = true;
        }

        private void pictureBox4_MouseEnter(object sender, EventArgs e)
        {
            label4.Visible = true;
        }

        private void pictureBox4_MouseLeave(object sender, EventArgs e)
        {
            label4.Visible = false;
        }

        private void pictureBox4_MouseMove(object sender, MouseEventArgs e)
        {
            if (miscare)
            {
                //noua pozitie a imaginii
                pictureBox4.Top += e.Y - y;
                pictureBox4.Left += e.X - x;
            }
        }

        private void pictureBox4_MouseUp(object sender, MouseEventArgs e)
        {
            miscare = false;
            Collision();
        }

        private void pictureBox5_MouseDown(object sender, MouseEventArgs e)
        {
            //pozitia initiala a cursorului
            x = e.X;
            y = e.Y;
            miscare = true;
        }

        private void pictureBox5_MouseEnter(object sender, EventArgs e)
        {
            label5.Visible = true;
        }

        private void pictureBox5_MouseLeave(object sender, EventArgs e)
        {
            label5.Visible = false;
        }

        private void pictureBox5_MouseMove(object sender, MouseEventArgs e)
        {
            if (miscare)
            {
                //noua pozitie a imaginii
                pictureBox5.Top += e.Y - y;
                pictureBox5.Left += e.X - x;
            }
        }

        private void pictureBox5_MouseUp(object sender, MouseEventArgs e)
        {
            miscare = false;
            Collision();
        }

        private void pictureBox6_MouseDown(object sender, MouseEventArgs e)
        {
            //pozitia initiala a cursorului
            x = e.X;
            y = e.Y;
            miscare = true;
        }

        private void pictureBox6_MouseEnter(object sender, EventArgs e)
        {
            label6.Visible = true;
        }

        private void pictureBox6_MouseLeave(object sender, EventArgs e)
        {
            label6.Visible = false;
        }

        private void pictureBox6_MouseMove(object sender, MouseEventArgs e)
        {
            if (miscare)
            {
                //noua pozitie a imaginii
                pictureBox6.Top += e.Y - y;
                pictureBox6.Left += e.X - x;
            }
        }

        private void pictureBox6_MouseUp(object sender, MouseEventArgs e)
        {
            miscare = false;
            Collision();
        }

        private void pictureBox7_MouseDown(object sender, MouseEventArgs e)
        {
            //pozitia initiala a cursorului
            x = e.X;
            y = e.Y;
            miscare = true;
        }

        private void pictureBox7_MouseEnter(object sender, EventArgs e)
        {
            label7.Visible = true;
        }

        private void pictureBox7_MouseLeave(object sender, EventArgs e)
        {
            label7.Visible = false;
        }

        private void pictureBox7_MouseMove(object sender, MouseEventArgs e)
        {
            if (miscare)
            {
                //noua pozitie a imaginii
                pictureBox7.Top += e.Y - y;
                pictureBox7.Left += e.X - x;
            }
        }

        private void pictureBox7_MouseUp(object sender, MouseEventArgs e)
        {
            miscare = false;
            Collision();
        }

        private void pictureBox8_MouseDown(object sender, MouseEventArgs e)
        {
            //pozitia initiala a cursorului
            x = e.X;
            y = e.Y;
            miscare = true;
        }

        private void pictureBox8_MouseEnter(object sender, EventArgs e)
        {
            label8.Visible = true;
        }

        private void pictureBox8_MouseLeave(object sender, EventArgs e)
        {
            label8.Visible = false;
        }

        private void pictureBox8_MouseMove(object sender, MouseEventArgs e)
        {
            if (miscare)
            {
                //noua pozitie a imaginii
                pictureBox8.Top += e.Y - y;
                pictureBox8.Left += e.X - x;
            }
        }

        private void pictureBox8_MouseUp(object sender, MouseEventArgs e)
        {
            miscare = false;
            Collision();
        }

        private void pictureBox9_MouseDown(object sender, MouseEventArgs e)
        {
            //pozitia initiala a cursorului
            x = e.X;
            y = e.Y;
            miscare = true;
        }

        private void pictureBox9_MouseEnter(object sender, EventArgs e)
        {
            label9.Visible = true;
        }

        private void pictureBox9_MouseLeave(object sender, EventArgs e)
        {
            label9.Visible = false;
        }

        private void pictureBox9_MouseMove(object sender, MouseEventArgs e)
        {
            if (miscare)
            {
                //noua pozitie a imaginii
                pictureBox9.Top += e.Y - y;
                pictureBox9.Left += e.X - x;
            }
        }

        private void pictureBox9_MouseUp(object sender, MouseEventArgs e)
        {
            miscare = false;
            Collision();
        }
        private void Collision()
        {
            pictureBox10.Image = null;
            if (pictureBox1.Bounds.IntersectsWith(pictureBox2.Bounds) && pictureBox1.Bounds.IntersectsWith(pictureBox3.Bounds))
            {
                pictureBox1.Enabled = false;
                pictureBox2.Enabled = false;
                pictureBox3.Enabled = false;
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                pictureBox10.Image = Image.FromFile("bifa.png");
                label10.Text = "Metiloranje";
                pictureBox1.Location = new Point(775, 175);
                pictureBox2.Location = new Point(700, 175);
                pictureBox3.Location = new Point(625, 170);
                nr++;
                if (nr == 4)
                {
                    this.Hide();
                    Form5 f = new Form5();
                    f.Show();
                }
            }
            if (pictureBox4.Bounds.IntersectsWith(pictureBox7.Bounds))
            {
                pictureBox4.Enabled = false;
                pictureBox7.Enabled = false;
                pictureBox4.Visible = false;
                pictureBox7.Visible = false;
                pictureBox10.Image = Image.FromFile("bifa.png");
                label10.Text = "Novolac";
                pictureBox4.Location = new Point(515, 170);
                pictureBox7.Location = new Point(500, 250);
                nr++;
                if (nr == 4)
                {
                    this.Hide();
                    Form5 f = new Form5();
                    f.Show();
                }
            }
            if (pictureBox5.Bounds.IntersectsWith(pictureBox6.Bounds))
            {
                pictureBox5.Enabled = false;
                pictureBox6.Enabled = false;
                pictureBox5.Visible = false;
                pictureBox6.Visible = false;
                pictureBox10.Image = Image.FromFile("bifa.png");
                label10.Text = "Celosolv";
                pictureBox5.Location = new Point(450, 170);
                pictureBox6.Location = new Point(425, 250);
                nr++;
                if (nr == 4)
                {
                    this.Hide();
                    Form5 f = new Form5();
                    f.Show();
                }
            }
            if (pictureBox8.Bounds.IntersectsWith(pictureBox9.Bounds))
            {
                pictureBox8.Enabled = false;
                pictureBox9.Enabled = false;
                pictureBox8.Visible = false;
                pictureBox9.Visible = false;
                pictureBox10.Image = Image.FromFile("bifa.png");
                label10.Text = "Acid Ftalic";
                pictureBox8.Location = new Point(575, 250);
                pictureBox9.Location = new Point(650, 250);
                nr++;
                if (nr == 4)
                {
                    this.Hide();
                    Form5 f = new Form5();
                    f.Show();
                }
            }

            if (pictureBox1.Bounds.IntersectsWith(pictureBox4.Bounds) || pictureBox1.Bounds.IntersectsWith(pictureBox5.Bounds) || pictureBox1.Bounds.IntersectsWith(pictureBox7.Bounds) || pictureBox1.Bounds.IntersectsWith(pictureBox8.Bounds) || pictureBox1.Bounds.IntersectsWith(pictureBox9.Bounds) || pictureBox1.Bounds.IntersectsWith(pictureBox6.Bounds) || pictureBox2.Bounds.IntersectsWith(pictureBox4.Bounds) || pictureBox2.Bounds.IntersectsWith(pictureBox5.Bounds) || pictureBox2.Bounds.IntersectsWith(pictureBox6.Bounds) || pictureBox2.Bounds.IntersectsWith(pictureBox7.Bounds) || pictureBox2.Bounds.IntersectsWith(pictureBox8.Bounds) || pictureBox2.Bounds.IntersectsWith(pictureBox9.Bounds) || pictureBox3.Bounds.IntersectsWith(pictureBox4.Bounds) || pictureBox3.Bounds.IntersectsWith(pictureBox5.Bounds) || pictureBox3.Bounds.IntersectsWith(pictureBox6.Bounds) || pictureBox3.Bounds.IntersectsWith(pictureBox7.Bounds) || pictureBox3.Bounds.IntersectsWith(pictureBox8.Bounds) || pictureBox3.Bounds.IntersectsWith(pictureBox9.Bounds) || pictureBox4.Bounds.IntersectsWith(pictureBox5.Bounds) || pictureBox4.Bounds.IntersectsWith(pictureBox6.Bounds) || pictureBox4.Bounds.IntersectsWith(pictureBox8.Bounds) || pictureBox4.Bounds.IntersectsWith(pictureBox9.Bounds) || pictureBox5.Bounds.IntersectsWith(pictureBox7.Bounds) || pictureBox5.Bounds.IntersectsWith(pictureBox8.Bounds) || pictureBox5.Bounds.IntersectsWith(pictureBox9.Bounds) || pictureBox6.Bounds.IntersectsWith(pictureBox7.Bounds) || pictureBox6.Bounds.IntersectsWith(pictureBox8.Bounds) || pictureBox6.Bounds.IntersectsWith(pictureBox9.Bounds) || pictureBox7.Bounds.IntersectsWith(pictureBox8.Bounds) || pictureBox7.Bounds.IntersectsWith(pictureBox9.Bounds))
            {
                pictureBox10.Image = Image.FromFile("x.png");
                if (pictureBox1.Enabled == true)
                {
                    pictureBox1.Location = new Point(775, 175);
                }
                if (pictureBox2.Enabled == true)
                {
                    pictureBox2.Location = new Point(700, 175);
                }
                if (pictureBox3.Enabled == true)
                {
                    pictureBox3.Location = new Point(625, 170);
                }
                if (pictureBox4.Enabled == true)
                {
                    pictureBox4.Location = new Point(535, 170);
                }
                if (pictureBox5.Enabled == true)
                {
                    pictureBox5.Location = new Point(450, 170);
                }
                if (pictureBox6.Enabled == true)
                {
                    pictureBox6.Location = new Point(425, 250);
                }
                if (pictureBox7.Enabled == true)
                {
                    pictureBox7.Location = new Point(500, 250);
                }
                if (pictureBox8.Enabled == true)
                {
                    pictureBox8.Location = new Point(575, 250);
                }
                if (pictureBox9.Enabled == true)
                {
                    pictureBox9.Location = new Point(650, 250);
                }
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f = new Form1();
            f.Show();
        }
    }
}
