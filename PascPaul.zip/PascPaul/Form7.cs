﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PascPaul
{
    public partial class Form7 : Form
    {
        int nr = 0;
        public Form7()
        {
            InitializeComponent();
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox5.Visible = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            WindowState = FormWindowState.Maximized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form10 f = new Form10();
            f.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f = new Form1();
            f.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            nr++;
            if (nr == 1)
                label1.Visible = true;
            if (nr == 2)
                label2.Visible = true;
            if (nr == 3)
                label3.Visible = true;
            if (nr == 4)
                label4.Visible = true;
            if (nr == 5)
                pictureBox1.Visible = true;
            if (nr == 6)
                label5.Visible = true;
            if (nr == 7)
                pictureBox2.Visible = true;
            if (nr == 8)
                label7.Visible = true;
            if (nr == 9)
                pictureBox3.Visible = true;
            if (nr == 10)
                label6.Visible = true;
            if (nr == 11)
                pictureBox4.Visible = true;
            if (nr == 12)
                pictureBox5.Visible = true;
            if (nr == 13)
                label8.Visible = true;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }
    }
}
