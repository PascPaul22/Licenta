﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace PascPaul
{
    public partial class Form8 : Form
    {
        string sir;
        string[] a = new string[100];
        string[,] b = new string[100, 100];
        string[,] r = new string[100, 100];
        string[] t = new string[100];
        string cuv;
        int[] rasp = new int[7];
        int n = 0, k = 1, v = 6, pct = 0, ok = 0, g;
        public Form8()
        {
            InitializeComponent();
            pictureBox2.Visible = false;
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox5.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            button3.Visible = false;
            button3.Enabled = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            using (StreamReader f = new StreamReader(Path.GetFullPath("intrebari.txt")))
            {
                while ((sir = f.ReadLine()) != null)

                    if (v == 6)
                    {
                        a[++n] = sir;
                        v = 1;
                    }
                    else
                    {
                        b[n, v] = sir;
                        int lg = 0;
                        if (v <= 5)
                        {
                            label2.Text = b[n, v];
                            t = b[n, v].Split(' ');
                            foreach (string cuv in t)
                                r[n, lg++] = cuv;
                            v++;
                        }
                        else
                            v = 1;

                    }

            }
            label1.Text = a[k];
            checkBox1.Text = b[k, 1];
            checkBox2.Text = b[k, 2];
            checkBox3.Text = b[k, 3];
            checkBox4.Text = b[k, 4];
            label2.Text = "Punctaj";
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            int  j;
            bool bine = false;
            //label3.Text = pct.ToString();
                cuv = r[k, 0];
                rasp[k] = Int32.Parse(cuv);
                if (a[k] == label1.Text)
                {
                    for (j = 1; j <= rasp[k]; j++)
                    {
                        if (checkBox1.Text == r[k, j] && ok <=rasp[k])
                        {
                            ok++;
                            bine = true;
                            checkBox1.Enabled = false;
                        }
                    }
                    if (bine == false)
                    {
                        g++;
                        ok = 0;
                        label2.Text = "Ați greșit cel puțin o variantă, punctajul este:" + (pct).ToString();
                    }
                }
           
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f = new Form1();
            f.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 f = new Form6();
            f.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (k <= n)
            {
                cuv = r[k, 0];
                rasp[k] = Int32.Parse(cuv);
                if (ok == rasp[k] && g == 0)
                {
                    pct++;
                    label2.Text = "Punctajul: " + pct.ToString();
                    if (k == 1)
                        pictureBox2.Visible = true;
                    if (k == 2)
                        pictureBox3.Visible = true;
                    if (k == 3)
                        pictureBox4.Visible = true;
                    if (k == 4)
                        pictureBox5.Visible = true;
                    if (k == 5)
                        pictureBox6.Visible = true;
                    if (k == 6)
                        pictureBox7.Visible = true;
                    ok = 0;
                    g = 0;
                }
                g = 0;
                ++k;
                if (k <= n)
                {
                    g = 0;
                    ok = 0;
                    checkBox1.Checked = false;
                    checkBox2.Checked = false;
                    checkBox3.Checked = false;
                    checkBox4.Checked = false;
                    checkBox1.Enabled = true;
                    checkBox2.Enabled = true;
                    checkBox3.Enabled = true;
                    checkBox4.Enabled = true;
                    label1.Text = a[k];
                    checkBox1.Text = b[k, 1];
                    checkBox2.Text = b[k, 2];
                    checkBox3.Text = b[k, 3];
                    checkBox4.Text = b[k, 4];
                    ok = 0;

                }
                else
                {
                    label1.Text = "Ați finalizat testul și ați acumulat " + pct.ToString() + " puncte";
                    checkBox1.Visible = false;
                    checkBox2.Visible = false;
                    checkBox3.Visible = false;
                    checkBox4.Visible = false;
                    button3.Visible = true;
                    button3.Enabled = true;
                }
            }
            else
                button2.Enabled = false;
        }
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            int j;
            bool bine = false;
               cuv = r[k, 0];
               rasp[k] = Int32.Parse(cuv);
                if (a[k] == label1.Text)
                {
                    for (j = 1; j <=rasp[k]; j++)
                    {
                        if (checkBox2.Text == r[k, j] && ok <=rasp[k])
                        {
                            ok++;
                            bine = true;
                            checkBox2.Enabled = false;
                        }
                    }
                    if (bine == false)
                    {
                        g++;
                        ok = 0;
                        label2.Text = "Ați greșit cel puțin o variantă, punctajul este:" + (pct).ToString();
                    }
                }
            
        }
        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            int j;
            bool bine = false;
            cuv = r[k, 0];
               rasp[k] = Int32.Parse(cuv);
            if (a[k] == label1.Text)
            {
                for (j = 1; j <= rasp[k]; j++)
                {
                    if (checkBox3.Text == r[k, j] && ok <= rasp[k])
                    {
                        ok++;
                        bine = true;
                        checkBox3.Enabled = false;
                    }
                }
                if (bine == false)
                {
                    g++;
                    ok = 0;
                    label2.Text = "Ați greșit cel puțin o variantă, punctajul este:" + (pct).ToString();
                }
            }
        }
        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            int j;
            bool bine = false;
               cuv = r[k, 0];
               rasp[k] = Int32.Parse(cuv);
                if (a[k] == label1.Text)
                {
                    for (j = 1; j <=rasp[k]; j++)
                    {
                        if (checkBox4.Text == r[k, j] && ok <=rasp[k])
                        {
                            ok++;
                            bine = true;
                            checkBox4.Enabled = false;
                        }
                    }
                    if (bine == false)
                    {
                        g++;
                        ok = 0;
                        label2.Text = "Ați greșit cel puțin o variantă, punctajul este:" + (pct).ToString();
                    }
                }
        }
    }
}
